package gr.aueb.cf.ch1;

/**
 * The program is calculating what is the sum of 63 + 4.
 * The expected result is 67.
 */

public class ExerciseThree {

    public static void main(String[] args) {

        int num1 = 63;
        int num2 = 4;
        int result = 0;

        result = num1 + num2;

        System.out.println("The result of addition is equal to " + result);

    }
}
