package gr.aueb.cf.ch1;

public class MenuApp {

    public static void main(String[] args) {
        System.out.println("Select one of the following options:");
        System.out.println();
        System.out.println("1. Introduction");
        System.out.println("2. Deletion");
        System.out.println("3. Search");
        System.out.println("4. Update");
        System.out.println("5. Exit");
        System.out.println();
        System.out.println("Provide a selection number: ");
    }
}
